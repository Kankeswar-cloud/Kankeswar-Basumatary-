import { useState } from "react";

export default function App() {
  const [prompt, setPrompt] = useState("");
  const [videoUrl, setVideoUrl] = useState("");
  const [status, setStatus] = useState("");

  const generate = async () => {
    const r = await fetch(`${process.env.REACT_APP_API}/generate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt })
    });
    const job = await r.json();

    let done = false;
    while (!done) {
      const s = await fetch(`${process.env.REACT_APP_API}/status/${job.id}`);
      const d = await s.json();
      setStatus(d.status);
      if (d.status === "completed" && d.output?.videoUrl) {
        setVideoUrl(d.output.videoUrl);
        done = true;
      }
      await new Promise(r => setTimeout(r, 5000));
    }
  };

  return (
    <div style={{ padding: "20px", fontFamily: "sans-serif" }}>
      <h1>AI Video Generator</h1>
      <input
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        placeholder="Enter your prompt..."
        style={{ width: "100%", padding: "8px" }}
      />
      <button onClick={generate} style={{ marginTop: "10px", padding: "10px 20px" }}>
        Generate
      </button>
      <p>Status: {status}</p>
      {videoUrl && <video controls src={videoUrl} style={{ marginTop: "20px", width: "100%" }} />}
    </div>
  );
}
